from django.contrib import admin
from django.contrib.auth.models import User as User1
# Register your models here.
# admin.site.unregister(User1)
