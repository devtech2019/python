import pgeocode
from os import PRIO_PGRP
from django.utils.html import strip_tags

from django.contrib.auth.decorators import permission_required
from django.contrib.contenttypes.models import ContentType
from atexit import register
from email import message
from operator import sub
from re import template
from django.shortcuts import render
from geopy.geocoders import Nominatim
import hashlib


from datetime import timedelta
from django.core.signing import TimestampSigner
# Create your views here.
from django import http
from django.contrib.auth import hashers
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.template.defaultfilters import add
from .models import *
# from staff_admin.models import training_user
from django.core.files.storage import FileSystemStorage
from django.core.exceptions import ValidationError
import math
import random
from .helpers import *
from django.contrib.auth.hashers import MD5PasswordHasher, make_password
from django.db.models import Q
# from django.contrib.auth import get_user_model
from django.contrib.auth import authenticate, login as login_check
from django.conf import settings
import json
from django.db.models import Count
import calendar
from django.utils import timezone
import qrcode
import qrcode.image.svg
from django.views.decorators.cache import never_cache
import base64
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.views.decorators.csrf import csrf_exempt
from fpdf import FPDF
from django.utils.timezone import utc
from django import template
from django.contrib.auth.models import  Group, Permission
from django import template
from encrypted_id import ekey

# Count Employer and Applicant and Jobs
# register = template.Library()


# @register.filterFajax
# def to_char(value):
#     return chr(98-value) 



@login_required(login_url='/admin/')
def dashboard(request):
    userdata = User.objects.all()
    count_emp = User.objects.filter(
        soft_del_status=0, roll='employer').count()
    count_sub = User.objects.filter(
        soft_del_status=0, roll='Subadmin').count()
    count_app = User.objects.filter(
        soft_del_status=0, roll='applicant').count()
    count_user = count_app + count_emp
    employer_query = f"""
        select id, count(*) as total,strftime("%%m",created_at) as month 
        from staff_admin_user where roll="employer" and soft_del_status=0 group by strftime("%%m",created_at);

    """
    employer_user_count = User.objects.raw(employer_query)

    applicant_query = f"""
                select id, count(*) as total,strftime("%%m",created_at) as month 
                from staff_admin_user where roll="applicant" and soft_del_status=0 group by strftime("%%m",created_at);
            """
    applicant_user_count = User.objects.raw(applicant_query)

    i = 0
    append_in_month_name = []
    employer_data = []
    while (i <= 11):
        i += 1

        obj = dict()
        obj.update(
            {'employer_total': 0, 'month': calendar.month_name[i], 'applicant_total': 0})
        convert_in_month_name = calendar.month_name[i]
        employer_data.append(obj)
    for user in employer_user_count:
        employer_data[int(user.month) - 1]['employer_total'] = user.total

    for user in applicant_user_count:
        employer_data[int(user.month) - 1]['applicant_total'] = user.total
    context = {
        'userdata': userdata,
        'count_user': count_user,
        'count_emp': count_emp,
        'count_app': count_app,
        'employer_data': employer_data,
        "employer_user_count": employer_user_count,
        "count_sub": count_sub

    }
    return render(request, 'base/dashboard.html', context)


# Admin Login Function with SuperUser
@never_cache

def login(request):
    try:
        if request.method == 'POST':
            email = request.POST.get('Email')
            password = request.POST.get('password')
            v = User.objects.get(email=email)
            request.session['email'] = email
            user = auth.authenticate(email=email,  password=password)
            
            
            if user.roll == 'Subadmin' or user.is_superuser :
                if user is None:
                    messages.error(request, "Invalid username or password ")
                    return redirect('/admin/')
                
                
                
                if user.is_superuser == True:
                    auth.login(request, user)
                    print('superuserrrrrrrrrrrrrrrrrrrrrrrrrrr')
                    return redirect('/admin/dashboard/')
               
                if user.email:
                    
                    
                    
                    if v.user_status == False:
                        # request.session['subadmin'] = v.soft_del_status                        
                        # print(request.session['subadmin'], "session subadminnnnnnnnnnnnnnnnnnnnnnnnnnnnnn")
                        
                        auth.login(request, user)
            
                        print( 'subadminnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn')
                        return redirect('/admin/dashboard/')
                    
                    
                    elif user.email:
                        auth.logout(request)
                        messages.error(request, "Permission denied")

                        return redirect('/admin/')
                    else:
                        
                        auth.logout(request)
                        messages.error(request, "Permission denied")

                        
                        return redirect('/admin/dashboard/')
                    
                   
                
                elif user.roll == 'Subadmin ' is None:
                    messages.error(request, "Invalid Username or Password ")
                    return redirect('/admin/')
                
               
            else:
                print("wwwwwwwwwwwwwww")
                messages.error(request, "Invalid Username or Password ")
                return redirect('/admin/')
            
        else:
            if request.user.is_active == True:
               return redirect('/admin/dashboard/')
            else:
                return render(request, 'auth/login.html')
    except:
        print("fffffffffffffffffffff")
        messages.error(request, "Invalid Username or Password " , )

        return render(request, 'auth/login.html')


# Admin Logout function
@login_required(login_url='/admin/')
def logout(request):
    auth.logout(request)
    return redirect('/admin/')


# Display Employer data
@permission_required('staff_admin.view_user', raise_exception=True)

@login_required(login_url='/admin/')
def employer_user_data(request):

    try:
        emp_user = User.objects.filter(roll='employer', soft_del_status=0)     
        userdata = User.objects.all()
        return render(request, 'user/employer/employer.html', {'emp_user': emp_user, 'userdata': userdata})
    except:
        messages.error(request , "Something Went Wronge")
        return render(request, 'user/employer/employer.html',)


def employer_view_data(request , slug):
    emp_user = User.objects.get(slug=slug , roll='employer')
    userdata = User.objects.all()
    return render(request, 'user/employer/view.html', {'emp_user': emp_user, 'userdata': userdata})

 
# Employer Status Via Ajax
@login_required(login_url='/admin/')
def employer_user_ajax(request, id):
    status = request.POST.get('select')
    print(status,"dddddddddddddddddddddddddddddddddd")
    if status:

        ob = User.objects.filter(id=id).update(user_status=status)
        x = User.objects.get(id=id)
        email = x.email 
        e = email_templates.objects.get(id=2)
        content = e.content
        # html_page = urllib2.urlopen(url)
     

        if status == '0':
            send_to = [email]

            subject = e.sub
            content = e.content
            name = x.first_name +" "+ x.last_name

            user_status = "Accepted"
            t = strip_tags(content)
            c = t.replace('{name}', name)
            msg = c.replace('{LINK}', user_status)
            sendMail(subject, msg, send_to)
            return JsonResponse({"status": "success", "message": "Status changed successfully !!!!"}, status=200)

        else :
            send_to = [email]
            subject = e.sub
            content = e.content
            name = x.first_name +" "+ x.last_name
            
            user_status = "Rejected"
            
            t = strip_tags(content)
            
            c = t.replace('{name}', name)
         
            msg = c.replace('{LINK}', user_status )
           
            
            sendMail(subject, msg, send_to)
            return JsonResponse({"status": "success", "message": "Status changed successfully !!!!"}, status=200)
   
    else:
        return JsonResponse({"status": "error", "message": "Status changed successfully !!!!"}, status=200)


# Applicant Status Via Ajax
@login_required(login_url='/admin/')
def applicant_user_ajax(request, id):
    status = request.POST.get('select')
    ob = User.objects.filter(id=id).update(user_status=status)

    x = User.objects.get(id=id)
    email = x.email
    e = email_templates.objects.get(id=2)
    if status == '0':
        send_to = [email]

        subject = e.sub
        content = e.content + "     " + "Accepted"
        sendMail(subject, content, send_to)
        return JsonResponse({"status": "success", "message": "Status changed successfully !!!!"}, status=200)
    else:
        send_to = [email]

        subject = e.sub
        content = e.content + "     " + "Rejected"
        sendMail(subject, content, send_to)
        return JsonResponse({"status": "error", "message": " Status changed successfully !!!!"}, status=200)



# Zenerate PDF for Employer 
def employer_user_data_pdf(request, id):
    emp_user = User.objects.filter(id=id, roll='employer')
    
    # getting the template
    pdf = html_to_pdf('reports/pdf/employer_details_pdf.html',{'emp_user': emp_user})
    # rendering the template
    return HttpResponse(pdf, content_type='application/pdf')



# Adding Employer User data
@permission_required('staff_admin.add_user', raise_exception=True)

@login_required(login_url='/admin/')
def emp_add_userdata(request):
    try:
        if request.method == 'POST':
            gen_pass = generatePassword()
            id = request.POST.get('id')

            first_name = request.POST.get('FName')
            last_name = request.POST.get('LName')
            company_name = request.POST.get('CName')
            latitude = request.POST.get('latitude')
            longitude = request.POST.get('longitude')

            email = request.POST.get('email')
            mobile_number = request.POST.get('phone')
            address = request.POST.get('address')
            code = mobile_number.split(' ')[0]
            latitude = request.POST.get('latitude')
            longitude = request.POST.get('longitude')
            phone = mobile_number.split(' ')[1]
            # country = request.POST.get('country')  
            # state = request.POST.get('state')
            # city = request.POST.get('city')
            # postal = request.POST.get('Postal_code')
            user_type = request.POST.get('emp')
            if user_type == 'employer':
                if User.objects.filter(email=email):
                    messages.error(request, 'email allready exits')
                    return redirect('/admin/employer/add/')
                else:
                    userdata = User.objects.create(first_name=first_name, last_name=last_name, company=company_name, email=email, company_profile_status=False ,latitude=latitude, longitude=longitude, password=make_password(
                        gen_pass), mobile_number=phone, country_code=code, address=address, roll=user_type)
                    unique_id = userdata.id + 100
                    send_to = [email]
                    subject = 'Your Password is Here '
                    content = 'Hi' + first_name + last_name + 'Your UNIQUE ID IS  ' + str(unique_id) + ' And Your Zenerated Password is  ' + gen_pass
                    sendMail(subject, content, send_to)
                    messages.success(
                        request, " Employer User Created and password sent on mail ")
                    return redirect('/admin/employer/')
        else:
            userdata = User.objects.all()
            country = Country.objects.all()

            return render(request, 'user/employer/add.html', {'userdata': userdata, 'country': country})
        # return render(request, 'user/employer/add.html')
    except:
        messages.error(request, 'Something Went Wrong')
        return redirect('/admin/employer/add/')


def emp_country_ajax(request):
    country = request.POST.get('select_country')
    state = States.objects.filter(country_id=country).values()

    # print(state.state_code,"dddddddddddddddddddddddddddddddddddddddd")
    # nomi = pgeocode.Nominatim('fr')
    
    if state is None:
        return JsonResponse({"status": "error", "message": " no changed !!!!", "result":"Required state"}, status=200)
    else:

        return JsonResponse({"status": "error", "message": " no changed !!!!", "result": list(state)}, status=200)


def emp_state_city_ajax(request):
    state = request.POST.get('state_value')
    
    city = Cities.objects.filter(state_id=state).values()
    # cities = json.dumps(city)
    print(city,"ffffffffffffffffffffffffffffffffff")

    # print(state.state_code,"dddddddddddddddddddddddddddddddddddddddd")
    # nomi = pgeocode.Nominatim('fr')

    if city is None:
        return JsonResponse({"status": "error", "message": " no changed !!!!"}, status=200)
    else:

        return JsonResponse({"status": "error", "message": " no changed !!!!", "result": list(city)}, status=200)




def emp_postal_code_ajax(request):
    postal_code = request.POST.get('postal_code')
  
    geolocator = Nominatim(user_agent="geoapiExercises")
    zipcode = postal_code
    location = geolocator.geocode(zipcode)
    nomi = pgeocode.Nominatim('fr')
    # print(dir(nomi)[10:], "ddddddddddddddddddddddddddddddddddddddddddddd")
    print(nomi.country, "ddddddddddddddddddddddddddddddddddddddddddddd")

    # print(location, "ddddddddddddddddddddddddddddddddddddddddddddd")

    return JsonResponse({"status": "error", "message": " no changed !!!!",  "location":list(location)}, status=200)



# Editing Employer data
@login_required(login_url='/admin/')
@permission_required('staff_admin.change_user', raise_exception=True)
def emp_edit_userdata(request, slug):
    # signer = TimestampSigner()
    # print(value,"ffffffffffffffffffffff")
    # try:
        if request.method == 'POST':
            slug = request.POST.get('slug')
            first_name = request.POST.get('FName')
            latitude = request.POST.get('latitude')
             
            longitude = request.POST.get('longitude')
            
            last_name = request.POST.get('LName')
            company_name = request.POST.get('CName')

            email = request.POST.get('email')
            mobile_number = request.POST.get('phone')
            address = request.POST.get('address')
            # country = request.POST.get('country')
            # state = request.POST.get('state')
            # city = request.POST.get('city')
            # postal = request.POST.get('Postal_code')
            user_type = request.POST.get('emp')
            try:
                if mobile_number == '' or mobile_number == ' ' or mobile_number == None:
                    userdata = User.objects.filter(slug=slug).update(first_name=first_name, last_name=last_name,  address=address,
                                                                     roll=user_type,  company=company_name, latitude=latitude, longitude=longitude)
                    messages.success(request, " Employer details is updated ")
                    return redirect('/admin/employer/')
                else:
                    code = mobile_number.split(' ')[0]
                    phone = mobile_number.split(' ')[1]
                    print(code,"ggggggggggggggggggg")
                    userdata = User.objects.filter(slug=slug).update(first_name=first_name, last_name=last_name, mobile_number=phone, country_code=code,
                                                                     address=address, roll=user_type, company=company_name, latitude=latitude, longitude=longitude)
                    messages.success(request, " Employer details is updated ")
                    return redirect('/admin/employer/')
            except:
                userdata = User.objects.filter(slug=slug).update(first_name=first_name, last_name=last_name,  country_code=code,
                                                                 address=address,  company=company_name, roll=user_type, latitude=latitude, longitude=longitude)
                messages.success(request, "Employer details is updated ")

                return redirect('/admin/employer/')

        else:
            country = Country.objects.all()
            users = User.objects.filter(slug=slug)
            user = User.objects.get(slug=slug)
            state = States.objects.filter(country_id=user.country_id).values()
            city = Cities.objects.filter(state_id=user.state_id).values()
            userdata = User.objects.all()
            return render(request, 'user/employer/edit.html', {'country': country, 'users': users, 'state': state, 'city': city, 'userdata': userdata})

    # except:
    #     messages.error(request, "Something Went Wrong")
    #     return redirect('/admin/employer/edit')
       


@login_required(login_url='/admin/')
def emp_search(request):
    if request.method == 'GET':
        u = request.GET.get('Q_emp')
        emp_user = User.objects.filter(
            first_name__icontains=u,  roll="employer" , soft_del_status=0)
        if emp_user:
            userdata = User.objects.all()
            return render(request, 'user/employer/employer.html', {'emp_user': emp_user, 'userdata': userdata})

        else:
            userdata = User.objects.all()
            u = "NO EMPLOYER FOUND"
            return render(request, 'user/employer/employer.html', {'u': u, ' userdata': userdata})

    else:
        userdata = User.objects.all()
        return render(request, 'user_data.html', {' userdata ': userdata})
# Deleting Employer Data
@permission_required('staff_admin.delete_user', raise_exception=True)

@login_required(login_url='/admin/')
def emp_userdata_del(request, id):
    instance = User.objects.get(id=id)
    instance.delete()
    messages.error(request, " Client User is deleted ")
    return redirect('/admin/employer/')


# Display Applicant data
@permission_required('staff_admin.view_user', raise_exception=True)
@login_required(login_url='/admin/')
def applicant_user_data(request):
    app_user = User.objects.filter(roll='applicant', soft_del_status=0)
    userdata = User.objects.all()
    return render(request, 'user/applicant/applicant.html', {'app_user': app_user, 'userdata': userdata})

# Display View data
def applicant_view_data(request, id):
    app_user = User.objects.get(id=id, roll='applicant')
    userdata = User.objects.all()
    return render(request, 'user/applicant/view.html', {'app_user': app_user, 'userdata': userdata})






# Appicant details In PDF
def applicant_user_data_pdf(request ,id ):
    app_user = User.objects.filter( id=id, roll='applicant')
    print(app_user)
    # getting the template
    pdf = html_to_pdf('reports/pdf/applicant_details_pdf.html',{'app_user': app_user})
    # rendering the template
    return HttpResponse(pdf, content_type='application/pdf')

# Adding Employer User data
@permission_required('staff_admin.add_user', raise_exception=True)
@login_required(login_url='/admin/')
def app_add_userdata(request):
    try:
        # mob = []
        if request.method == 'POST':
            gen_pass = generatePassword()
            first_name = request.POST.get('FName')
            last_name = request.POST.get('LName')        
            email = request.POST.get('email')
            mobile_number = request.POST.get('phone')
            print(mobile_number,"dddddddddddddddddddddd")
            address = request.POST.get('address')
            code = mobile_number.split(' ')[0]
            latitude = request.POST.get('latitude')
            longitude = request.POST.get('longitude')

            phone = mobile_number.split(' ')[1]
            # print(code, "sssssssssssssssssssssssssssssssssssssssss")
            # country = request.POST.get('country')
            # state = request.POST.get('state')
            # city = request.POST.get('city')
            # postal = request.POST.get('Postal_code')
            job_position = request.POST.get('job')
            exp_year = request.POST.get('year')
            print(job_position, exp_year, address)

            # print(exp_year, exp_month, "gggggggggggggggggggggggggggggggggggggggg")
            user_type = request.POST.get('app')
            
            if user_type == 'applicant':

                if User.objects.filter(email=email):
                    messages.error(request, 'email allready exits')
                    return redirect('/admin/applicant/add/')
                else:
                    userdata = User.objects.create(first_name=first_name, latitude=latitude, company_profile_status=False,longitude=longitude,last_name=last_name, email=email, password=make_password(
                        gen_pass), exp_year=exp_year,  position_id=job_position, mobile_number=phone, country_code=code, address=address, roll=user_type,)
                    unique_id = userdata.id + 100
                    send_to = [email]
                    subject = 'Your Password is Here ' 
                    content = 'Hi' + first_name + last_name + 'Your UNIQUE ID IS  ' + str(unique_id) + ' And Your Zenerated Password is  ' + gen_pass
                    sendMail(subject, content, send_to)
                    messages.success(
                        request, " Applicant User Created and password sent on mail ")
                
                    
                    return redirect('/admin/applicant/')
        else:
            userdata = User.objects.all()
            country = Country.objects.all()
            job_postion = Category.objects.all()
            return render(request, 'user/applicant/add.html', {'userdata': userdata, 'country': country, 'job_postion': job_postion})

    except: 
        messages.error(
            request, " something went wrong ")
        return redirect('/admin/applicant/add/')
 
 

def app_job_position_ajax(request):
    job = request.POST.get('job_position')
    print(job ,"ddddddddddddddddddddddddddddddd")
    return JsonResponse({"status": "okay", "message": "  changed !!!!"})



# Editing Applicant data
@permission_required('staff_admin.change_user', raise_exception=True)

@login_required(login_url='/admin/')
def app_edit_userdata(request, slug):
    if request.method == 'POST':
        slug = request.POST.get('slug')

        first_name = request.POST.get('FName')

        last_name = request.POST.get('LName')           
        email = request.POST.get('email')
        mobile_number = request.POST.get('phone')
        address = request.POST.get('address')
        latitude = request.POST.get('latitude')
        longitude = request.POST.get('longitude')

        # country = request.POST.get('country')
        # state = request.POST.get('state')
        # city = request.POST.get('city')
        # postal = request.POST.get('Postal_code')
        user_type = request.POST.get('app')
        job_position = request.POST.get('job')
        exp_year = request.POST.get('year')
        # exp_month = request.POST.get('month')
        code = mobile_number.split(' ')[0]
        try:
            if mobile_number == '' or mobile_number == ' ' or mobile_number == None:

                    userdata = User.objects.filter(slug=slug).update(first_name=first_name, last_name=last_name,  address=address,
                                                                        exp_year=exp_year, latitude=latitude,  longitude=longitude, roll=user_type, position_id=job_position,)
                    messages.success(request, " Applicant details is updated ")
                    return redirect('/admin/applicant/')
            else:
                    code = mobile_number.split(' ')[0]
                    phone = mobile_number.split(' ')[1]
                    userdata = User.objects.filter(slug=slug).update(first_name=first_name, last_name=last_name, mobile_number=phone, country_code=code,
                                                                        exp_year=exp_year,  latitude=latitude,  longitude=longitude, position_id=job_position, address=address, roll=user_type,)
                    messages.success(request, " Applicant details is updated ")
                    return redirect('/admin/applicant/')
    
           
        except:
            
            userdata = User.objects.filter(slug=slug).update(
                first_name=first_name, last_name=last_name,
                exp_year=exp_year, address=address, roll=user_type, position_id=job_position, latitude=latitude,  longitude=longitude,)

            messages.success(request, "Employer details is updated ")
            return redirect('/admin/applicant/')
    else:
        userdata = User.objects.all()
        country = Country.objects.all()
        users = User.objects.filter(slug=slug)
        user = User.objects.get(slug=slug)
        job = Category.objects.all()
        state = States.objects.filter(country_id=user.country_id).values()
        city = Cities.objects.filter(state_id=user.state_id).values()
        return render(request, 'user/applicant/edit.html', {'users': users,'country':country,'state':state , 'job':job, 'city':city,'userdata': userdata})


@login_required(login_url='/admin/')
def app_search(request):
    try:
        if request.method == 'GET':
            u = request.GET.get('Q_app')
            app_user = User.objects.filter(
                first_name__icontains=u,  roll="applicant", soft_del_status=0)
            if app_user:
                userdata = User.objects.all()
                return render(request, 'user/applicant/applicant.html', {'app_user': app_user, 'userdata': userdata})

            else:
                userdata = User.objects.all()
                u = "NO APPLICANT FOUND"
                return render(request, 'user/applicant/applicant.html', {'u': u, ' userdata': userdata})

        else:
            userdata = User.objects.all()
            return render(request, 'user/applicant/applicant.html', {' userdata ': userdata})
    except:
        messages.error(request, "SomeThing Went wrong")
        userdata = User.objects.all()
        return render(request, 'user/applicant/applicant.html', {' userdata ': userdata})

# Deleting Applicant Data

@permission_required('staff_admin.delete_user', raise_exception=True)

@login_required(login_url='/admin/')
def app_userdata_del(request, id):
    instance = User.objects.get(id=id)
    instance.soft_delete()
    messages.error(request, " Applicant User is deleted ")
    return redirect('/admin/applicant/')


# def applicat_details_pdf(request):
   
#     pdf = html_to_pdf('app_pdf.html', {'count_app': count_app})
#     print(pdf, 'hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh')
#     # rendering the template
#     return HttpResponse(pdf, content_type='application/pdf')


@permission_required('staff_admin.view_job_category', raise_exception=True)

def category(request):
    cat = Category.objects.filter(soft_del_status=0)
    
    
    for i in cat:
       x=i.leave_day
       z=i.DAY_CHOISE
       print(z,'--------------')
       print(x)
       print(type(x))
       y=json.loads(x)
       print(type(y),'----------')
    #    y=x.replace('[','').replace(']','')
    #    z=y.split(',')
    #    for j in z:
        #   print(j,"gggggggggggggggggggggggggggggggggggggggggggggg")
       
    j=[1,2]
    userdata = User.objects.all()
    return render(request, 'job_category/category.html', {'cat': cat,  'userdata': userdata})


@permission_required('staff_admin.add_job_category', raise_exception=True)

def add_category(request):
    
    if request.method == 'POST':
        name = request.POST.get('name')
        week_hour = request.POST.get('Week')
        leave_day = request.POST.getlist('Leave[]')
        shift_diffrence = request.POST.get('Shift')
        
       

        status = request.POST.get('status')
        z= json.dumps(leave_day)
        cat = Category.objects.create(
        name=name, week_hour=week_hour, leave_day=z, shift_diffrence=shift_diffrence, status=status)
            
        messages.success(request, 'Successfully ! Job Category Created')
        return redirect('/admin/category/')
    else:
        userdata = User.objects.all()
        u = Category.DAY_CHOISE

        return render(request, 'job_category/add.html', {'userdata': userdata , 'u':u})


@permission_required('staff_admin.edit_job_category', raise_exception=True)

def edit_category(request, slug):
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('name')
        week_hour = request.POST.get('Week')
        leave_day = request.POST.getlist('Leave[]')
        shift_diffrence = request.POST.get('Shift')
        print(leave_day ,"fffffffffffffffffffffffffffff")
        
        leave=json.dumps(leave_day)
        print(leave)

        status = request.POST.get('status')
       
        cat = Category.objects.filter(slug=slug).update(
            name=name, week_hour=week_hour, leave_day=leave, shift_diffrence=shift_diffrence, status=status)

        messages.success(request, 'Successfully ! Job Category Updated')
        return redirect('/admin/category/')
    else:
        userdata = User.objects.all()
        cat = Category.objects.get(slug=slug)
        
        u = Category.DAY_CHOISE

        x = json.loads(cat.leave_day)
        print(type(x))
        print(type(u),'----------------')
        
        return render(request, 'job_category/edit.html', {'userdata': userdata, 'days': u,'select_day':x, 'cat': cat})



@permission_required('staff_admin.delete_job_category', raise_exception=True)
def del_category(request, id):
    cat = Category.objects.get(id=id)
    cat.soft_delete()
    messages.error(request, 'Successfully ! Job Category Deleted' )
    return redirect('/admin/category/')


# Searching UserData from User Database



# Update Admin Profile
@login_required(login_url='/admin/')

def myprofile(request, id):
    if request.method == 'POST':
        id = request.POST.get('id')
        username = request.POST.get('username')
        email = request.POST.get('email')
        image = request.FILES.get('img')
        u = User.objects.get(id=id)
        if u.is_superuser:
            try:
                if image is None:
                    userdata = User.objects.get(id=id)
                    userdata.username = username
                    userdata.email = email
                    userdata.save()
                    messages.success(
                        request, " 'Successfully ! Profile Details is Updated ")
                    return redirect('/admin/myprofile/' + id)
                    

                else:

                    userdata = User.objects.get(id=id)
                    user = userdata.image
                    userdata.username = username
                    userdata.email = email
                    user.delete()
                    userdata.image = image
                    userdata.save()
                    messages.success(request, 'Successfully ! Profile Details is Updated')
                    return redirect('/admin/myprofile/' + id)
            except:
                messages.error(request, " Email allready register ")
                return redirect('/admin/myprofile/' + id)

        elif u.roll == 'Subadmin':
            try:
                if image is None:
                    userdata = User.objects.get(id=id)
                    userdata.username = username
                    userdata.email = email
                    userdata.save()
                    messages.success(request, 'Successfully ! Profile Details is Updated')
                    return redirect('/admin/myprofile/' + id)

                else:

                    userdata = User.objects.get(id=id)
                    user = userdata.image
                    userdata.username = username
                    userdata.email = email
                    user.delete()
                    userdata.image = image
                    userdata.save()
                    messages.success(request, 'Successfully ! Profile Details is Updated')
                    return redirect('/admin/myprofile/' + id)

            except:
                messages.error(request, " Email allready register ")
                return redirect('/admin/myprofile/' + id)

    else:
        userdata = User.objects.all()
        u = User.objects.get(id=id)
        return render(request, 'admin_profile/myprofile.html', {'userdata': userdata, 'u':u})


# Changing Password from admin
@login_required(login_url='/admin/')
def change_password(request):
    if request.method == 'POST':
        Cpwd = request.POST.get('Cpwd')
        Npwd = request.POST.get('Npwd')
        user = User.objects.get(id=request.user.id)
        un = user.username
        check = user.check_password(Cpwd)
        if check == True:
            user.set_password(Npwd)
            user.save()
            user = User.objects.get(username=un)
            login_check(request, user)
            messages.success(request, " Password changed Successfully !!!! ")
            return redirect('/admin/change_password/')
        else:
            messages.error(request, " Old Password is Wrong ")
            return redirect('/admin/change_password/')
    else:
        user = User.objects.get(id=request.user.id)
        userdata = User.objects.all()
        return render(request, "admin_profile/change_password.html", {'user': user, 'userdata': userdata})


# Forgotpassword via link on gmail
def forgotpassword(request):
    
    try:
        if request.method == 'POST':
            email = request.POST.get('Email')

            e = email_templates.objects.get(id=1)

            
            u = User.objects.get(email=email)
            print(u,'kkkkkkkkkkkkkkkkkkkkk')
            
         

            if u.is_superuser:
                o = generateOTP()
                us = hash(o)
                currnt_time = datetime.now()
                 
                u.OTP_string = us
                u.reset_time_link = str(currnt_time)

                u.save()

                send_to = [email]
                subject = e.sub
                
                content = e.content 
                a = request.build_absolute_uri()
               
                url = a +'forgotpasswordform/'+ str(us)
                t = strip_tags(content)
                c = t.replace('{name}', u.username)
                msg = c.replace('{LINK}', url)
                print(msg)



                sendMail(subject, msg, send_to)

                messages.success(request, " 'Successfully ! Link send on your mail")
                return redirect('/admin/forgotpassword/')
            elif u:
              

                messages.error(request, "Email is not exist")

                return redirect('/admin/forgotpassword/')
    except:
        messages.error(request, "Email is not exist")
        return redirect('/admin/forgotpassword/')

    return render(request, 'admin_profile/forgot_password.html')


# Change Forgot Password form
def forgot_password_form(request, slug ):
    if request.method == 'POST':
        slug = request.POST.get('us')
        email = request.POST.get('email')
        reset_time = request.POST.get('reset_time')
       
        o = request.POST.get('newpassword')
        u = request.POST.get('confirmpassword')
        # current_time = datetime.now()
        # c_time = current_time.replace(tzinfo=None)
        # old_time = reset_time.replace(tzinfo=None)

        # diff = c_time-old_time
        # x = diff.total_seconds() / 3600
        # now = datetime.now()
        # timediff = now.strptime - reset_time
        # print(diff, "gggggggggggggggggggggggggggggggggggggggggggggggggggg")

        if o == u:
            u = User.objects.filter(email=email, OTP_string=slug ).update(
                password=make_password(o))
            messages.success(request, 'Successfully ! Password Changed ')
            remove = User.objects.filter(
                email=email, OTP_string=slug).update(OTP_string=None)
            return redirect('/admin/')
        else:
            messages.error(request, "Password does not match")
            return redirect('/admin/forgot_password_form/' + slug)

    else:
        try:
            u = User.objects.get(OTP_string=slug)
            if u is None:
                print('no')
        except:
            return HttpResponse(
                ' <h1 style="margin-left:100px  " > Sorry Link is valid only one time</h1> <br> <button style="margin-left:100px "  class="btn btn-success" ><a class="btn btn-success" href="/admin/"> back to login</a></button>')
        userdata = User.objects.all()
        return render(request, 'admin_profile/forgot_password_form.html', {'userdata': userdata})


# Display Pages from pages model


@login_required(login_url='/admin/')
@permission_required('staff_admin.view_pages', raise_exception=True)
def Cms_Pages(request):
    terms = pages.objects.all()
    userdata = User.objects.all()
    return render(request, "cms_pages/pages/cms_pages.html", {'terms': terms, 'userdata': userdata})


# Add Pages from pages model


@login_required(login_url='/admin/')
@permission_required('staff_admin.add_pages', raise_exception=True)

def add_Cms_Pages(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('editor')
        data = pages.objects.create(title=title, content=content)
        data.save()
        messages.success(request, 'CMS Pages is added ')
        return redirect('/admin/Cms_Pages/')
    terms = pages.objects.all()
    userdata = User.objects.all()
    return render(request, 'cms_pages/pages/add.html', {'terms': terms, 'userdata': userdata})


# Edit Pages from pages model


@login_required(login_url='/admin/')
@permission_required('staff_admin.change_pages', raise_exception=True)

def edit_Cms_Pages(request, slug):
    # try:
        if request.method == 'POST':
            title = request.POST.get('title')
            text = request.POST.get('text')
            content = request.POST.get('editor')
            # img2 = request.FILES.get('img2')
            img2 = request.FILES.get('img2')
            # print(img2 ,"fffffffffffffffffffffffffffffffffffffffffffffffff") 
            
            # print(img2,"ffffffffffffffffffffffffffffffffffffffff")
            if content is " ".strip():
                messages.error(request, 'content required')
                return redirect('/admin/Cms_Pages/' + slug)
            elif img2 is None:
                
                messages.success(request, 'Pages is updated ')
                data = pages.objects.filter(slug=slug).update(
                    title=title, content=content)
                return redirect('/admin/Cms_Pages')
            
            elif img2:
                fs = FileSystemStorage()
                filename = fs.save(img2.name, img2)
                messages.success(request, 'Pages is updated ')
                data = pages.objects.filter(slug=slug).update(
                    title=title, image=img2,  content=content)
                return redirect('/admin/Cms_Pages')
            elif text:
                messages.success(request, 'Pages is updated ')
                data = pages.objects.filter(slug=slug).update(
                    title=title, image=img2, text=text,  content=content)
                return redirect('/admin/Cms_Pages')
            

        else:
            terms = pages.objects.filter(slug=slug)
            userdata = User.objects.all()
            return render(request, 'cms_pages/pages/edit.html', {'terms': terms, 'userdata': userdata})
    # except:
    #     messages.error(request, 'Something Went wrong ')
    #     return redirect('/admin/edit_Cms_Pages/'+ slug)



# if image is None:
#                     userdata = User.objects.get(id=id)
#                     userdata.username = username
#                     userdata.email = email
#                     userdata.save()
#                     messages.success(request, " Profile details is updated ")
#                     return redirect('/admin/myprofile/' + id)


#                 else:

#                     userdata = User.objects.get(id=id)
#                     user = userdata.image
#                     userdata.username = username
#                     userdata.email = email
#                     user.delete()
#                     userdata.image = image
#                     userdata.save()
#                     messages.success(request, " Profile details is updated ")
#                     return redirect('/admin/myprofile/' + id)















# Delete Pages from pages model

@login_required(login_url='/admin/')
@permission_required('staff_admin.delete_pages', raise_exception=True)

def delete_Cms_Pages(request, slug):
    instance = pages.objects.get(slug=slug)
    instance.soft_delete()
    messages.error(request, " deleted ")
    return redirect('/admin/Cms_Pages/')


# Display Email_tem from email model
# @permission_required('user.Subadmin')
@permission_required('staff_admin.view_email_templates', raise_exception=True)

@login_required(login_url='/admin/')
def Email_tem(request):
    email = email_templates.objects.all()
    userdata = User.objects.all()
    return render(request, 'cms_pages/email/email.html', {'email': email, 'userdata': userdata})


#  Add_email from email model


@login_required(login_url='/admin/')
@permission_required('staff_admin.add_email_templates', raise_exception=True)

def add_email(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        sub = request.POST.get('subject')
        content = request.POST.get('content')
        email = email_templates.objects.create(
            name=name, sub=sub, content=content)
        email.save()
        messages.success(request, 'Email Templates is Created ')
        return redirect('/admin/email')
    return render(request, 'cms_pages/email/add.html')


#  Edit_email from email model

@login_required(login_url='/admin/')
@permission_required('staff_admin.change_email_templates', raise_exception=True)

def edit_email(request, slug):
    if request.method == 'POST':
        id = request.POST.get('id')
        name = request.POST.get('name')
        sub = request.POST.get('subject')
        content = request.POST.get('content')
        email = email_templates.objects.filter(slug=slug).update(
            name=name, sub=sub, content=content)
        messages.success(request, 'Successfully !  Updated Email Templates')
        return redirect('/admin/email')
    email = email_templates.objects.filter(slug=slug)
    userdata = User.objects.all()
    return render(request, 'cms_pages/email/edit.html', {'email': email, 'userdata': userdata})


#  del_email_tem from email model

@permission_required('staff_admin.delete_email_templates', raise_exception=True)

@login_required(login_url='/admin/')
def del_email_tem(request, id):
    email = email_templates.objects.get(id=id)
    email.soft_delete()
    messages.error(request, 'Email Templates is delete ')
    return redirect('/admin/email/')


# Display global_setting from email model

# @permission_required('staff_admin.view_global_setting', raise_exception=True)
# @login_required(login_url='/admin/')
# def global_setting(request):
#     e = Global_setting.objects.filter(soft_del_status=0)
#     userdata = User.objects.all()
#     return render(request, 'cms_pages/global/global.html', {'userdata': userdata, 'e': e})


# Add global_setting from email model
# @login_required(login_url='/admin/')
# @permission_required('staff_admin.add_global_setting', raise_exception=True)
# def add_global_setting(request):
#     if request.method == 'POST':
#         name = request.POST.get('name')
#         email = request.POST.get('email')
#         img = request.FILES.get('image')
#         print(img,"ffffffffffffffffffffff")
#         facebook_link = request.POST.get('facebook')
#         instagram_link = request.POST.get('instagram')
#         twitter_link = request.POST.get('pintrest')

#         pintrest_link = request.POST.get('pintrest')
#         linkdin_link = request.POST.get('linkdin')
#         details = request.POST.get('editor')

#         if Global_setting.objects.filter(email=email).exists():
#             messages.error(request, 'email allready')
#             return redirect('/admin/global/add')
#         else:
#             fs = FileSystemStorage()
#             filename = fs.save(img.name, img)
#             global_setting = Global_setting.objects.create(name=name, twitter_link=twitter_link, email=email, img=filename,
#                                                            facebook_link=facebook_link,
#                                                            instagram_link=instagram_link, pintrest_link=pintrest_link,
#                                                            linkdin_link=linkdin_link, discripion=details)
#             global_setting.save()
#             messages.success(request, 'global setting Templates is Created ')

#             return redirect('/admin/global')
#     userdata = User.objects.all()
#     return render(request, 'cms_pages/global/add.html', {'userdata': userdata})


# Edit global_setting from email model
@login_required(login_url='/admin/')
@permission_required('staff_admin.change_global_setting', raise_exception=True)

def edit_global_setting(request, slug):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        img = request.FILES.get('image')
        facebook_link = request.POST.get('facebook')
        instagram_link = request.POST.get('instagram')
        twitter_link = request.POST.get('pintrest')

        pintrest_link = request.POST.get('pintrest')
        linkdin_link = request.POST.get('linkdin')
        details = request.POST.get('editor')
        try:
            if img is None:
                
                global_setting = Global_setting.objects.filter(slug=slug).update(name=name, email=email,
                                                                                 twitter_link=twitter_link,
                                                                                 facebook_link=facebook_link,
                                                                                instagram_link=instagram_link,
                                                                                 pintrest_link=pintrest_link,
                                                                                 linkdin_link=linkdin_link,
                                                                                 discripion=details)

                messages.success(
                    request, 'Successfully ! Global setting is Updated ')
                return redirect('/admin/global/edit/' + slug)
            else:
                fs = FileSystemStorage()
                filename = fs.save(img.name, img)
                global_setting = Global_setting.objects.filter(slug=slug).update(name=name, img=filename,
                                                                                 twitter_link=twitter_link, email=email,
                                                                                 facebook_link=facebook_link,
                                                                                 instagram_link=instagram_link,
                                                                                 pintrest_link=pintrest_link,
                                                                                 linkdin_link=linkdin_link,
                                                                                 discripion=details)

                messages.success(
                    request, 'global_setting Templates is Updated ')
                return redirect('/admin/global/edit/' + slug)
        except:
            messages.error(request, 'Email allreday register')
            return redirect('/admin/global/edit/' + slug)

    userdata = User.objects.all()
   

    global_setting = Global_setting.objects.get(slug=slug)
    return render(request, 'cms_pages/global/edit.html',{'userdata': userdata, 'global_setting': global_setting})


# Delete global_setting from email model
# @login_required(login_url='/admin/')
# @permission_required('staff_admin.delete_global_setting', raise_exception=True)

# def del_global_setting(request, slug):
#     global_setting = Global_setting.objects.get(slug=slug)
#     global_setting.soft_delete()
#     messages.error(request, 'global setting is delete ')
#     return redirect('/admin/global/')


# Qr Code Zenerate
@permission_required('staff_admin.view_qr_code', raise_exception=True)
def qr_code(request):
    if request.method == "POST":
        Qr_url = request.POST.get('name')
        QR_save = Qr_Code.objects.create(Qr_url=Qr_url)
        messages.success(request, "wahhhhhhhhh bate ")
        return redirect('/admin/qr_code')
    else:
        qr_code = Qr_Code.objects.all()
        return render(request, 'base/qr_code.html', {'qrcode': qr_code})

# Delete Qr Code
@permission_required('staff_admin.delete_qr_code', raise_exception=True)
def delete_qr(request, id):
    qr = Qr_Code.objects.get(id=id)
    qr.delete()
    messages.error(request, "very bad bate ")
    return redirect('/admin/qr_code')



#  ChatProcess Code
@permission_required('staff_admin.delete_qr_code', raise_exception=True)
@login_required(login_url='/admin/')
def chat_view(request):
    users=[]
    chat_with=""
    print("chat view: ",request.user.roll)
    if request.user.roll == "applicant":
        users = User.objects.filter(roll="admin")
        chat_with="Admin"
    if request.user.roll == "employer":
        users = User.objects.filter(roll="admin")
        chat_with="Admin"
    if request.user.roll == "admin":
        users = User.objects.filter(Q(roll="applicant") | Q(roll="employer"))
        chat_with="Applicant or Employer"
    threads = Thread.objects.by_user(user=request.user).prefetch_related('chatmessage_thread').order_by('timestamp')
    userdata = User.objects.all()

    context = {
        'threads': threads,
        "users":users,
        "chat_with":chat_with,
        'userdata':userdata
      
    }
    return render(request, 'chat.html', context, )
# Sending message via Ajax
def chat_ajax(request):
    if request.method == 'POST':
        data = request.POST.get('select')
        return JsonResponse({"status": "success", "message": "Status changed successfully !!!!"}, status=200)
    return JsonResponse({"status": "error", "message": "NO Status changed successfully !!!!"}, status=404)

# Display Reports 
def reports_list(request):
    userdata = User.objects.all()
    count_emp = User.objects.filter(soft_del_status=0, roll='employer').count()
  

    count_app = User.objects.filter(soft_del_status=0, roll='applicant').count()
    
    return render(request, 'reports/reports.html', {'count_emp': count_emp,'count_app': count_app, 'userdata': userdata})


# Zenerate Employee PDF
def emp_pdf(request):
    count_emp = User.objects.filter(
        soft_del_status=0, roll='employer').count()
    print(count_emp ,"ddddddddddddddddddddddd")
        # getting the template
    all_emp = User.objects.filter(soft_del_status=0, roll='employer').values()
    print(all_emp,"ddddddddddddddddddddddddddddddddddddddddddddd")
    pdf = html_to_pdf('reports/pdf/emp_pdf.html', {'count_emp': count_emp , 'all_emp':all_emp})
 
        # rendering the template
    return HttpResponse(pdf, content_type='application/pdf')

# Zenerate Applicant PDF
def app_pdf(request):
    count_app = User.objects.filter(
        soft_del_status=0, roll='applicant').count()
    all_app = User.objects.filter(soft_del_status=0, roll='applicant').values()

    # getting the template
    pdf = html_to_pdf('reports/pdf/app_pdf.html',
                      {'count_app': count_app, 'all_app': all_app})
    # rendering the template
    return HttpResponse(pdf, content_type='application/pdf')



@permission_required('staff_admin.view_training', raise_exception=True)
# Display Training Managment
def training(request):
    trainings = Training.objects.filter(soft_del_status=0)
    userdata = User.objects.all()
    return render(request, 'training/training.html', {'training': trainings,'userdata':userdata})


# Add Training Managment
@login_required(login_url='/admin/')

def add_training(request):
    try:
        if request.method == 'POST':
            training_name = request.POST.get('training_name')
            user = request.POST.getlist('training-user[]')

            status = request.POST.get('status')
            
            training = Training.objects.create(
                training_name=training_name, Status=status)
            for i in user:
                training.user.add(int(i))
                training.save()
            messages.success(request, 'Successfully ! Training is added')
            return redirect( '/admin/training')
        else:
            userdata = User.objects.all()
            return render(request, 'training/add.html', {'userdata': userdata})
    except:
        messages.error(request, 'Training is not added ')
        return redirect( '/admin/add')

# Edit Training Managment


@login_required(login_url='/admin/')
def edit_training(request, id):

    try:
        obj = Training.objects.get(id=id)
        l = obj.user.all()
        if request.method == 'POST':
            
            training_name = request.POST.get('training_name')
            status = request.POST.get('status')
            userlist = request.POST.getlist('userlist[]')
            
            
            if training_name and status:
                obj.training_name = training_name
                obj.Status = status
                obj.save()
            if userlist:
                obj.user.set(userlist)
                obj.save()
            userdata = User.objects.all()
            messages.success(request, 'Successfully ! Training is Updated ')
            return redirect('/admin/training')
        else:
            obj = Training.objects.get(id=id)
            l = obj.user.all()
            user_list = []
            for i in l:
                user_list.append(i.id) 
            print(user_list,"ffffffffffffffffffffff")

            userdata = User.objects.all()
           
            return render(request, 'training/edit.html', {'old_data': l, 'obj': obj, 'user_list': user_list, 'userdata': userdata})
    except:
        messages.error(request, 'Training is not update')
        return redirect('/admin/edit')


# Delete Training Managment
def del_training(request, id):
    training = Training.objects.get(id=id)
    training.soft_delete()
    messages.error(request, 'Successfully ! Training is Deleted  ')
    return redirect('/admin/training/')


@login_required(login_url='/admin/')

def subadmin(request):
    user_subadmin = User.objects.filter(roll='Subadmin', soft_del_status=0)
   
   
    Per = Permission.objects.filter(user=request.user)
  
    userdata = User.objects.all()
    return render(request, "subadmin/subadmin.html", {'user_subadmin': user_subadmin, 'Per': Per, 'userdata': userdata})


@login_required(login_url='/admin/')

def add_subadmin(request):
    try:
        if request.method == "POST":
            Name = request.POST.get('Name')
            email = request.POST.get('email')
            mobile_number = request.POST.get('phone')
            address = request.POST.get('address')
            subadmin = request.POST.get('subadmin')
            status = request.POST.get('status')
            permission = request.POST.getlist('name[]')
            print(permission, '+++++++++++++++')
            print(request.POST)
            code = mobile_number.split(' ')[0]
            phone = mobile_number.split(' ')[1]
            gen_pass = generatePassword()
            sub = User.objects.create(username=Name, password=make_password(
                gen_pass), user_status=status, email=email, mobile_number=phone, country_code=code,  address=address,  roll=subadmin)
            send_to = [email]
            subject = 'Your Password is Here '
            content = 'Hi' + Name + ' Your Zenerated Password is  ' + gen_pass
            sendMail(subject, content, send_to)
            for i in permission:
                user = User.objects.get(id=sub.id)
                user.user_permissions.add(i)

            messages.success(
                request, 'Sub admin added successfully ! Please check your email for Login and password')
            return redirect('/admin/subadmin/')
        else:
            userdata = User.objects.all()
            c = ContentType.objects.filter(app_label='staff_admin')
            
            
            # print(s,"ffffffffffffffffffffffffffffff")
            # q = Job_Category
            # w = q.split('_')
            # s = w[0]
            # print(s)
            model_list = ['user', 'training', 'category',
                            'pages',  'email_templates' ,'global_setting',  ]
            
            # print(q,"ddddddddddddddddddddddddddddddddddddddddddddd")
            t = list()
            for i in c:
                if i.model in model_list:
                    t.append(i.id)
                else:
                    pass

            l1 = list()

            for i in t:

                per = Permission.objects.filter(content_type_id=i)

                x = list()
                c = 1
                for i in per:
                    if c == 1:
                        s_name = i.content_type.model.split('_')

                        if len(s_name) > 1:
                            s = ''
                            for name in s_name:
                                   if name == 0:
                                        s = name.title()
                                   else:
                                        s = s+' '+name.title()
                            x.append(s)
                        else:
                            x.append(s_name[0].title())

                        c += 1
                    else:
                        pass
                    if 'view' in i.name:
                        x.append({'View': i.id})

                    if 'add' in i.name:

                        x.append({'Add': i.id})
                    elif 'change' in i.name:
                        x.append({'Edit': i.id})

                    elif 'delete' in i.name:
                        x.append({'Delete': i.id})

                try:
                    l1.append(x)
                except:
                    pass

            print(l1, 'fkdfdlkfdl----------------')

            return render(request, "subadmin/add.html", {'l': l1, 'userdata': userdata})
    except:
        messages.error(request, ' Subadmin is created Failed !')
        return redirect('/admin/subadmin/add')


@login_required(login_url='/admin/')
def edit_subadmin(request, slug):
    try:
        if request.method == 'POST':

            Name = request.POST.get('Name')
            email = request.POST.get('email')
            mobile_number = request.POST.get('phone')
            address = request.POST.get('address')
            subadmin = request.POST.get('subadmin')
            status = request.POST.get('status')
            permission = request.POST.getlist('name[]')
            if mobile_number == None or mobile_number == '':
                sub = User.objects.filter(slug=slug).update(
                    username=Name, user_status=status, email=email,  address=address,  roll=subadmin)
            else:
                code = mobile_number.split(' ')[0]
                phone = mobile_number.split(' ')[1]
                sub = User.objects.filter(slug=slug).update(username=Name, user_status=status, email=email,
                                                            mobile_number=phone, country_code=code,  address=address,  roll=subadmin)
            user = User.objects.get(slug=slug)
            user.user_permissions.clear()

            for i in permission:
                user = User.objects.get(slug=slug)

                user.user_permissions.add(i)
            messages.success(request, ' Successfully ! Subadmin is Updated ')
            return redirect('/admin/subadmin/')

        else:
            users = User.objects.filter(slug=slug)
            userdata = User.objects.all()
            u = User.objects.get(slug=slug)

            c = ContentType.objects.filter(app_label='staff_admin')
            model_list = ['user','training', 'global_setting',
                          'job_category', 'email_templates', 'pages']
            t = []
            for i in c:
                if i.model in model_list:
                    t.append(i.id)
                else:
                    pass

            l1 = []

            for i in t:

                per = Permission.objects.filter(content_type_id= i)

                x = []
                c = 1
                for i in per:
                    if c ==1:
                        s_name = i.content_type.model.split('_')

                        if len(s_name) > 1:
                            s = ''
                            for name in s_name:
                                   if name == 0:
                                        s = name.title()
                                   else:
                                        s = s+' '+name.title()
                            x.append(s)
                        else:
                            x.append(s_name[0].title())

                        c += 1
                    else:
                        pass
                    if 'view' in i.name:
                        x.append({'View': i.id})

                    if 'add' in i.name:

                        x.append({'Add': i.id})
                    elif 'change' in i.name:
                        x.append({'Edit': i.id})

                    elif 'delete' in i.name:
                        x.append({'Delete': i.id})

                try:
                    l1.append(x)
                except:
                    pass

            permission_id = u.user_permissions.filter(user__slug=slug)
            l = []
            for i in permission_id:

                l.append(i.id)
            return render(request, 'subadmin/edit.html', {'users': users, 'userdata': userdata, 'l':l1 , 'list':l})
    except:
        messages.error(request, ' Subadmin is not update  ')
        return redirect('/admin/subadmin/edit/'+str(id))


# def del_submin(request, id):
#     user = User.objects.get(id=id)
#     user.soft_delete()
#     messages.error(request, "delete subadmin")
#     return redirect('/admin/subadmin')


def del_submin(request, id):
    
    instance = User.objects.get(id=id)

    instance.soft_delete()
    request.session['subadmin'] = instance.soft_del_status
    print(request.session['subadmin'] ,"fffffffffffffffffffff")
    del request.session['subadmin']

    
    
    
    messages.error(request, "Successfully ! Subadmin is deleted")
    return redirect('/admin/subadmin/')


@login_required(login_url='/admin/')
def contact(request):
    con = ContactUs.objects.all()
    print(con)
    return render(request , "contact.html", {'con':con})


@login_required(login_url='/admin/')
def contact_reply(request ,id ):
    if request.method == 'POST':

      
        email = request.POST.get('email')
        # print(email)
        
        sub = request.POST.get('sub')
        content = request.POST.get('content')
        print(content,"ffffffffffffffffffffff")
        # e = email_templates.objects.get()
        send_to=[email]

        subject=sub
        content=content
        sendMail(subject, content, send_to)
   
    reply = ContactUs.objects.get(id=id)

    return render(request, "contact_reply.html", {'reply': reply})


def del_contact(request, id):
    
    reply = ContactUs.objects.get(id=id)
    reply.delete()
    messages.error(request, "Successfully ! Contact is deleted")
    return redirect('/admin/contact/')




def App_intro(request):
    intro = AppWebIntro.objects.all()
    return render(request , 'cms_pages/intro/intro.html',{'intro':intro})


def edit_App_intro(request , slug):
    if request.method == 'POST':
        slug = request.POST.get('slug')
        
        title = request.POST.get('title')
        Image = request.FILES.get('img')
        
       
        Discription = request.POST.get('Discription')
        intro = AppWebIntro.objects.get(slug=slug)
        
        if Image is None:
            
            intro.slug = slug
            intro.title = title
            intro.textarea = Discription
            intro.save()
            print("dddddddddddddddddddddd")
            return redirect('/admin/introduction/')

        else:
            fs = FileSystemStorage()
            filename = fs.save(Image.name, Image)
            intro.slug = slug
            intro.title = title
            intro.image = Image
            intro.textarea = Discription
            intro.save()
            return redirect('/admin/introduction/')
    intro = AppWebIntro.objects.get(slug=slug)
    return render(request, 'cms_pages/intro/edit.html' , {'intro':intro})



























# @api_view([ 'GET','POST'])
# @csrf_exempt
# def s_api(request):
#     if request.method == 'GET':
#         s = s_test.objects.all()
#         serializer = s_testSerializer(s, many=True)
#         print(serializer.data, "gggggggggggggggggggggggggggggggggggggggggggggggggggg")

#         return JsonResponse(serializer.data ,safe=False)
#     elif request.method =='POST':
#         name = request.POST.get('name')
#         email = request.POST.get('email')
#         number = request.POST.get('number')
#         message = request.POST.get('message') 
#         # print(name, email, number, message) 
#         serializer = s_testSerializer(data= request.data)
#         if serializer.is_valid():
#             serializer.save()
#             print(serializer.data ,"gggggggggggggggggggggggggggggggggggggggg")
#             return JsonResponse({"status": "success", "message": "APi Bana DI hai mene !!!!"}, status=200)
#         return JsonResponse({"status": "error", "message": "Error Api !!!!"}, status=200)


# @api_view(['GET', 'PUT' ,'DELETE'])
# @csrf_exempt
# def s_api_details(request, id):
#     s = s_test.objects.get(id=id)
#     if request.method == 'GET':
       
#         serializer = s_testSerializer(s)

#         return JsonResponse(serializer.data, safe=False)
#     elif request.method == 'PUT':
#         serializer = s_testSerializer(s, data=request.data)
#         if serializer.is_valid():
#             serializer.save()
#             return JsonResponse({"status": "success", "message": "APi Update kr DI hai mene !!!!"}, status=200)
#         return JsonResponse({"status": "error", "message": "Error Api !!!!"}, status=200)
    
#     elif request.method == 'DELETE':
#         s.delete()
#         return HttpResponse(status=204)
           



       

   

