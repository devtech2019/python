import json

from channels.consumer import AsyncConsumer
from channels.db import database_sync_to_async
from .models import Thread, ChatMessage, User


class ChatConsumer(AsyncConsumer):
    async def websocket_connect(self, event):
        user = self.scope['user']
        print(user.roll)
        self.chat_room = f"user_chatroom_{user.id}"
        await self.channel_layer.group_add(
            self.chat_room,
            self.channel_name
        )
        await self.send({
            'type': 'websocket.accept',
        })

    async def websocket_receive(self, event):
        print("message received", event)
        data = json.loads(event["text"])
        print(data['sent_by'])
        print(data['sent_to'])
        msg = data.get('message', None)
        sent_by_id = data.get('sent_by', None)
        sent_to_id = data.get('sent_to', None)
        thread_id = data.get('thread_id')
        sent_by_user = await self.get_user_object(sent_by_id)
        sent_to_user = await self.get_user_object(sent_to_id)
        thread_obj = await self.get_thread(thread_id)
        if not sent_by_user:
            print('Error:: sent by user is incorrect')
        if not sent_to_user:
            print('Error:: send to user is incorrect')
        if not thread_obj:
            print('Error:: Thread id is incorrect')
        if sent_by_user:
            pass
        if sent_to_user:
            pass

        await self.create_chat_message(thread_obj, sent_by_user, msg)
        other_user_chatroom = f"user_chatroom_{sent_to_id}"
        self_user = self.scope['user']  # who logged in

        if msg:
            response = {
                'message': msg,
                'sent_by': self_user.id,
                # 'sent_by_user':self_user.username or self_user.email,
                'thread_id': thread_id,
            }
            # await self.send({
            #     'type': 'websocket.send',
            #     'text': json.dumps(response),
            # })

            await self.channel_layer.group_send(
                other_user_chatroom,
                {
                    'type': 'chat_message',
                    'text': json.dumps(response)
                }
            )
            await self.channel_layer.group_send(
                self.chat_room,
                {
                    'type': 'chat_message',
                    'text': json.dumps(response)
                }
            )

    async def websocket_disconnect(self, event):
        print("websocket disconnected", event)

    async def chat_message(self, event):
        print("chat_message", event)
        await self.send(
            {
                'type': 'websocket.send',
                'text': event['text']
            }
        )

    @database_sync_to_async
    def get_user_object(self, user_id):
        try:
            qs = User.objects.get(id=int(user_id))
        except:
            qs = None
        return qs

    @database_sync_to_async
    def get_thread(self, thread_id):
        try:
            obj = Thread.objects.get(id=thread_id)
        except:
            obj = None
        return obj

    @database_sync_to_async
    def create_chat_message(self, thread, user, msg):
        ChatMessage.objects.create(thread=thread, user=user, message=msg)
